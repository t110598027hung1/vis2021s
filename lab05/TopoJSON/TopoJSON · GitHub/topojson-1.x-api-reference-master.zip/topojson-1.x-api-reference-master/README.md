# TopoJSON 1.x API Reference

This is an archive of the TopoJSON 1.x API Reference from the [TopoJSON wiki](https://github.com/topojson/topojson/wiki).

For the current version of TopoJSON, see the [TopoJSON API Reference](https://github.com/topojson/topojson/blob/master/README.md).
