export var hasOwnProperty = Object.prototype.hasOwnProperty;
